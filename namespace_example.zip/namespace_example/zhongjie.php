<?php
/**
 * Created by PhpStorm.
 * User: Zhongjie FAN
 * Date: 2017-10-17
 * Time: 20:31
 */

namespace zhongjie_ns;
session_start();

include_once("db_config.php");

$var01 = "hello_zhongjie_var01";

function func01() {
    return "hello_zhongjie_func01";
}


echo "<h2>var01 in zhongjie.php: " . $var01 . "</h2>";
echo "<h2>func01 in zhongjie.php: " . func01() . "</h2>";


echo "<h2>" . \global_ns\db_connection::getConnect_static() . "</h2>";

$db_conn = new \global_ns\db_connection();
echo "<h2>" . $db_conn->getConnect_nonstatic() . "</h2>";

$_SESSION['hw']="hello world";


?>

