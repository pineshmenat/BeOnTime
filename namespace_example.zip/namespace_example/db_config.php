<?php

/**
 * Created by PhpStorm.
 * User: Zhongjie FAN
 * Date: 2017-10-17
 * Time: 20:39
 */

namespace global_ns;

class db_connection {

    const DB_SERVER = 'sql210.byethost16.com';
    const DB_PORT = '3306';
    const DB_USERNAME = 'b16_20802573';
    const DB_PASSWORD = 'beontime';
    const DB_DATABASE = 'b16_20802573_beontime';

    static private $db_connection;

    static function getConnect_static() {
//        return self::$db_connection = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_DATABASE, DB_PORT);;
        return self::$db_connection = "I'm db_connection in getConnect_static()";
    }

    public function getConnect_nonstatic() {
        return self::$db_connection = "I'm db_connection in getConnect_nonstatic()";
    }


}


?>