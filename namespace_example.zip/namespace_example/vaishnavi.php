<?php
/**
 * Created by PhpStorm.
 * User: Zhongjie FAN
 * Date: 2017-10-17
 * Time: 20:31
 */

namespace vaishnavi_ns;
session_start();

$var01 = "vaishnavi_var01";

function func01() {
    echo "vaishnavi_func01";
}

echo '_SESSION[\'hw\'] is: ' . $_SESSION['hw'];

session_destroy();
?>